package com.englishacademy.business;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.speech.tts.TextToSpeech;
import java.util.Locale;
public class MainActivity extends Activity {
 private WebView web;
 private TextToSpeech tts;
 private boolean ttsReady=false;
 public class SpeechBridge {
  @JavascriptInterface public void speak(final String word) {
   if(word==null || word.length()>200)return;
   runOnUiThread(new Runnable(){public void run(){if(ttsReady)tts.speak(word,TextToSpeech.QUEUE_FLUSH,null,"word");}});
  }
 }
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  tts=new TextToSpeech(this,new TextToSpeech.OnInitListener(){public void onInit(int status){if(status==TextToSpeech.SUCCESS){ttsReady=tts.setLanguage(Locale.US)>=0;}}});
  web=new WebView(this);
  web.setWebViewClient(new WebViewClient());
  WebSettings settings=web.getSettings();
  settings.setJavaScriptEnabled(true);
  settings.setDomStorageEnabled(true);
  settings.setAllowFileAccess(true);
  settings.setAllowContentAccess(false);
  web.addJavascriptInterface(new SpeechBridge(),"AndroidSpeech");
  setContentView(web);
  web.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){if(tts!=null){tts.stop();tts.shutdown();}if(web!=null)web.destroy();super.onDestroy();}
}
